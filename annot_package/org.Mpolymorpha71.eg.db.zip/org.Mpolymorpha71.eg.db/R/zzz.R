datacache <- new.env(hash=TRUE, parent=emptyenv())

org.Mpolymorpha71.eg <- function() showQCData("org.Mpolymorpha71.eg", datacache)
org.Mpolymorpha71.eg_dbconn <- function() dbconn(datacache)
org.Mpolymorpha71.eg_dbfile <- function() dbfile(datacache)
org.Mpolymorpha71.eg_dbschema <- function(file="", show.indices=FALSE) dbschema(datacache, file=file, show.indices=show.indices)
org.Mpolymorpha71.eg_dbInfo <- function() dbInfo(datacache)

org.Mpolymorpha71.egORGANISM <- "Marchantia polymorpha71"

.onLoad <- function(libname, pkgname)
{
    ## Connect to the SQLite DB
    dbfile <- system.file("extdata", "org.Mpolymorpha71.eg.sqlite", package=pkgname, lib.loc=libname)
    assign("dbfile", dbfile, envir=datacache)
    dbconn <- dbFileConnect(dbfile)
    assign("dbconn", dbconn, envir=datacache)

    ## Create the OrgDb object
    sPkgname <- sub(".db$","",pkgname)
    db <- loadDb(system.file("extdata", paste(sPkgname,
      ".sqlite",sep=""), package=pkgname, lib.loc=libname),
                   packageName=pkgname)    
    dbNewname <- AnnotationDbi:::dbObjectName(pkgname,"OrgDb")
    ns <- asNamespace(pkgname)
    assign(dbNewname, db, envir=ns)
    namespaceExport(ns, dbNewname)
        
    packageStartupMessage(AnnotationDbi:::annoStartupMessages("org.Mpolymorpha71.eg.db"))
}

.onUnload <- function(libpath)
{
    dbFileDisconnect(org.Mpolymorpha71.eg_dbconn())
}

